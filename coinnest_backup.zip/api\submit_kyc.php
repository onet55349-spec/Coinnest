<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $full_name = $_POST['full_name'];
    
    // File upload logic (simplified for demonstration)
    if (isset($_FILES['id_front'])) {
        $stmt = $pdo->prepare("INSERT INTO kyc_requests (user_id, full_name, status) VALUES (?, ?, 'pending')");
        $stmt->execute([$user_id, $full_name]);
        
        $stmt = $pdo->prepare("UPDATE users SET kyc_status = 'pending' WHERE id = ?");
        $stmt->execute([$user_id]);
        
        header("Location: ../profile.php?kyc_submitted=1");
        exit();
    }
}
header("Location: ../verification.php");
?>
