<?php
// api/admin_update_user.php
header('Content-Type: application/json');
require_once '../includes/db.php';
require_once '../includes/auth.php';

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data']);
    exit();
}

$user_id = $data['id'];
$balance = $data['balance'];
$win_rate = $data['win_rate'];

try {
    $stmt = $pdo->prepare("UPDATE users SET balance = ?, win_rate = ? WHERE id = ?");
    $stmt->execute([$balance, $win_rate, $user_id]);
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
