<?php
// includes/functions.php

/**
 * Get a setting value by key
 */
function getSetting($key, $pdo) {
    $stmt = $pdo->prepare("SELECT key_value FROM settings WHERE key_name = ?");
    $stmt->execute([$key]);
    return $stmt->fetchColumn();
}

/**
 * Update a setting value
 */
function updateSetting($key, $value, $pdo) {
    $stmt = $pdo->prepare("INSERT INTO settings (key_name, key_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE key_value = ?");
    return $stmt->execute([$key, $value, $value]);
}

/**
 * Get user balance
 */
function getUserBalance($userId, $pdo) {
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn();
}

/**
 * Format currency
 */
function formatCurrency($amount) {
    return '$' . number_format($amount, 2);
}
?>
