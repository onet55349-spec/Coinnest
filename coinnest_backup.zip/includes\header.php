<?php
// includes/header.php
require_once 'includes/db.php';
require_once 'includes/auth.php';
requireLogin();

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: logout.php");
    exit();
}

$page_title = isset($page_title) ? $page_title : "CoinNest";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoinNest | Global Crypto Trading Platform</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Montserrat:wght@800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
</head>
<body style="background: #050505;">
    <div class="bg-container"></div>

    <!-- Sidebar Menu -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>
    <div class="side-menu" id="sideMenu">
        <div class="side-menu-header">
            <span class="side-menu-logo">CoinNest</span>
            <i class="ph ph-x close-side-menu" onclick="toggleSidebar()"></i>
        </div>
        <div class="side-menu-list">
            <a href="dashboard.php" class="side-menu-item <?php echo ($active_page == 'dashboard') ? 'active' : ''; ?>">
                <i class="ph-fill ph-circles-four"></i>
                Market Terminal
            </a>
            <a href="history.php" class="side-menu-item <?php echo ($active_page == 'history') ? 'active' : ''; ?>">
                <i class="ph-fill ph-clock-counter-clockwise"></i>
                Trade History
            </a>
            <a href="support.php" class="side-menu-item <?php echo ($active_page == 'support') ? 'active' : ''; ?>">
                <i class="ph-fill ph-headset"></i>
                Customer Care
            </a>
            <a href="help.php" class="side-menu-item <?php echo ($active_page == 'help') ? 'active' : ''; ?>">
                <i class="ph-fill ph-info"></i>
                Help Center
            </a>
            <a href="logout.php" class="side-menu-item logout-item">
                <i class="ph-bold ph-sign-out"></i>
                Log Out
            </a>
        </div>
    </div>

    <div class="main-wrapper dash-wrapper">
        <header class="dash-header">
            <div style="display: flex; align-items: center; gap: 15px;">
                <i class="ph ph-list" style="font-size: 24px; color: #fff; cursor: pointer;" onclick="toggleSidebar()"></i>
                <h1 class="reg-logo" style="margin-bottom: 0;">CoinNest</h1>
            </div>
            <div style="display: flex; gap: 20px; align-items: center;">
                <a href="notifications.php" style="text-decoration: none;"><i class="ph ph-bell" style="font-size: 24px; color: #fff;"></i></a>
                <a href="profile.php" style="text-decoration: none;"><i class="ph ph-user-circle" style="font-size: 28px; color: #fff;"></i></a>
            </div>
        </header>

        <!-- Sidebar Toggle Script -->
        <script>
            function toggleSidebar() {
                const overlay = document.getElementById('sidebarOverlay');
                const menu = document.getElementById('sideMenu');
                if (overlay && menu) {
                    overlay.classList.toggle('active');
                    menu.classList.toggle('active');
                }
            }
        </script>
