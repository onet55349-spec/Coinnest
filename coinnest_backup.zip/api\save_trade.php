<?php
header('Content-Type: application/json');
require_once '../includes/db.php';
require_once '../includes/auth.php';

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

$user_id = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data provided']);
    exit();
}

$asset = $data['asset'] ?? 'BTC/USDT';
$type = $data['type'] ?? 'buy'; // buy or sell
$amount = floatval($data['amount'] ?? 0);
$entry_price = floatval($data['entry_price'] ?? 0);
$result_amount = floatval($data['result_amount'] ?? 0);
$status = $data['status'] ?? 'pending'; // win or loss

if ($amount <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid amount']);
    exit();
}

try {
    $pdo->beginTransaction();

    // Insert trade record
    $stmt = $pdo->prepare("INSERT INTO trades (user_id, asset, type, amount, entry_price, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $asset, $type, $amount, $entry_price, $status]);

    // Update user balance
    // If it's a win, they get result_amount (profit). If loss, they lose the amount.
    // In the frontend logic: resultAmount = isWin ? tradeAmount * winPercent : -tradeAmount;
    // So we just add result_amount to the balance (if result_amount is positive for win, or if they already deducted it and now we add profit).
    
    // Better logic: Deduct amount when trade starts, add (amount + profit) if win.
    // But since this API is called at the end of the 140s:
    
    $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->execute([$result_amount, $user_id]);

    $pdo->commit();

    echo json_encode(['success' => true, 'new_balance' => getBalance($user_id, $pdo)]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function getBalance($userId, $pdo) {
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn();
}
?>
