<?php
// includes/footer.php
?>
    </div> <!-- Close main-wrapper -->

    <!-- Bottom Navigation -->
    <nav class="bottom-nav">
        <a href="dashboard.php" class="nav-item <?php echo ($active_page == 'dashboard') ? 'active' : ''; ?>">
            <i class="ph-fill ph-chart-bar"></i>
            <span>Markets</span>
        </a>
        <a href="trade.php" class="nav-item <?php echo ($active_page == 'trade') ? 'active' : ''; ?>">
            <i class="ph ph-arrows-left-right"></i>
            <span>Trade</span>
        </a>
        <a href="wallet.php" class="nav-item <?php echo ($active_page == 'wallet') ? 'active' : ''; ?>">
            <i class="ph ph-wallet"></i>
            <span>Wallet</span>
        </a>
        <a href="notifications.php" class="nav-item <?php echo ($active_page == 'notifications') ? 'active' : ''; ?>">
            <i class="ph ph-bell"></i>
            <span>Alerts</span>
        </a>
    </nav>
</body>
</html>
